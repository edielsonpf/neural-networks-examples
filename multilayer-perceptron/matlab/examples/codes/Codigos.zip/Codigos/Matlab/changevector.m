function [xteste,dteste]  = changevector(xteste,dteste,nTeste)

xteste_aux = xteste; % Colocando os vetores em vetores auxiliares
dteste_aux = dteste;

cont_aux = randperm(nTeste);  % Usando fun��o para colocar aletoriedade nas disposi��es do Vetor de valida��o
for cont=1:nTeste,
    xteste(cont,:) = xteste_aux(cont_aux(cont),:);
    dteste(cont)   = dteste_aux(cont_aux(cont));
end
    





