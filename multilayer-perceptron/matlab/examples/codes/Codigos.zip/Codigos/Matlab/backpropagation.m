% function [w1 w2] = backpropagation(nEntradas,nEscondida,nSaidas,xt,dt,xv,dv,maxEpocas,etaSaida,etaEscondida,a,b)
% funcao para treino de uma rede neural multilayer perceptron
% com uma camada escondida.
% Os parametros de entrada sao:
% - nEntradas: dimensao do vetor de entrada
% - nEscondida: numero de neuronios na camada escondida
% - nSaidas: numero de neuronios na camada de saida
% - xt: matriz (nEntradas+1,nExemplos) com as entradas da rede para treinamento, onde nExemplos é o número de pares de treinamento.
% - dt: matriz (nSaidas,nExemplos) com as saídas desejadas para as respectivas entradas em xt.
% - xv e dv: idem a xt e dt, mas para os pares de validacao cruzada.
% - maxEpocas: número máximo permitido de épocas de treinamento
% - etaSaida: passo de aprendizagem da camada de saida
% - etaEscondida: passo de aprendizagem da camada escondida
% - a e b: parametros da funcao de ativacao: y = a*tanh(b*vj);
 
function [w1otimo,w2otimo,saturados] = backpropagation(nEntradas,nEscondida,nSaidas,xt,dt,xteste,dteste,xv,dv,maxEpocas,etaSaida,etaEscondida,a,b,nTeste,saturados)

% Verificando quantos exemplos de treinamento e validacao cruzada
t = size(xt);
nTreinamento = t(2);

% Criando a rede
%delta = 0.001; % faixa de variacao dos pesos iniciais
%w1 = unifrnd(-delta,delta,nEscondida,nEntradas+1);
%w2 = unifrnd(-delta,delta,nSaidas,nEscondida+1);

%calculando o melhor delta para que a rede tenha um melhor desempenho
delta1 = sqrt(3 /(nEntradas+1));
delta2 = sqrt(3 /(nEscondida+1));
w1 = unifrnd(-delta1,delta1,nEscondida,nEntradas+1);
w2 = unifrnd(-delta2,delta2,nSaidas,nEscondida+1);

%w1 = [-0.2 0.1 0.7;
%       0.3 -0.7 0.8;
%       0.5 0.3 -0.6;
%       0.4 0.5 -0.4];
%w2 = [0.1 0.3 -0.4 0.7 0.6;
%      -0.7 0.8 0.3 -0.4 0.5];
 

% Treinamento
eMedio = zeros(1,maxEpocas);
eMin = Inf;
epocas = 1;
while (epocas < maxEpocas)
  % Treinando a rede
  for i=1:nTreinamento
    [y,yh] = forward(w1,w2,a,b,xt(i,:));       % calculando saida da rede
    for extra=1:nEscondida,
        if (yh(extra)>0.9*a)
            saturados = saturados +1;
        end
    end
    for extra=1:nSaidas,
        if (y(extra)>0.9*a)
            saturados = saturados +1;
        end
    end    
    [w1,w2] = backward(w1,w2,a,b,xt(i,:),yh,y,dt(i,:),etaSaida,etaEscondida); % atualizando pesos
  end%for   

  % Validacao cruzada
  eMedio(epocas) = valida(w1,w2,a,b,xv,dv);

  % Salvando rede de melhor desempenho
  if (eMedio(epocas) < eMin)
    eMin = eMedio(epocas);
    epocaminimo = epocas;
    w1otimo = w1;
    w2otimo = w2;
  end%if

  % Mudando a ordem de apresenta��o dos exemplos
  [xteste,dteste]  = changevector(xteste,dteste,nTeste);
  
  epocas=epocas+1;
end%while

% Mostrando evolucao do erro medio com as epocas
%figure(1);
%plot(eMedio);
figure(1)
plot(eMedio,'-');
grid on
title('Analise do desempenho de uma rede MLP');
ylabel('Erro');
xlabel('Epoca');
axis([0 maxEpocas 0 1]);

%caption ["Melhor epoca: " int2str(epocaminimo)]

%endfunction

