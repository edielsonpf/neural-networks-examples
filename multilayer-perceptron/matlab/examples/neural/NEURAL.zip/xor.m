clear all
% Dados da rede neural
nEntradas = 2; % numero de sinais de entrada
nEscondida = 20; % numero de neuronios da camada escondidaa
nSaidas = 1; % numero de neuronios da camada de saida
eta1=0.7; % passo de aprendizagem da camada escondida
eta2=0.5; % passo de aprendizagem da camada de saida
c1=0.1;    % w1 será inicializada com valores aleatórios com dist. uniforme entre -c1 e +c1
c2=0.1;    % w2 será inicializada com valores aleatórios com dist. uniforme entre -c2 e +c2
maxEpocas=10000;

% Gerando pares de treinamento
xt=[0 0 1 1;0 1 0 1];
dt=[1 0 0 1];

% Gerando pares de validacao cruzada
xv=[0 0 1 1;0 1 0 1];
dv=[1 0 0 1];

% Gerando pares de teste
xe=[0 0 1 1;0 1 0 1];
de=[1 0 0 1];
Ne=4;

[w1,w2] = treina(xt,dt,xv,dv,nEntradas,nEscondida,nSaidas,eta1,eta2,c1,c2,maxEpocas);



