nEntradas = 2; % numero de sinais de entrada
nEscondida = 2; % numero de neuronios da camada de entrada
nSaidas = 1; % numero de neuronios da camada de saida
eta1=0.5; % passo de aprendizagem da camada escondida
eta2=0.7; % passo de aprendizagem da camada de saida
c1=0.01;    % w1 será inicializada com valores aleatórios com dist. uniforme entre -c1 e +c1
c2=0.01;    % w2 será inicializada com valores aleatórios com dist. uniforme entre -c2 e +c2
maxEpocas=1;

w1=[.2 .1 .5;.3 .4 .2];
w2=[.7 .5 .2];
delta1=zeros(size(w1)); % camada de entrada
delta2=zeros(size(w2)); % camada de saida
a = 1.7159;
b = 2.0/3.0;




   


      % Entrada modificada (insercao do limiar de ativacao)
      y0=[1;1;1]
      pause
      % Saida da camada escondida
      y1=a*tanh(b*w1*y0)

      % Entrada da camada de saida
      y2=[1;y1]

      % Saida da camada de saida (saida da rede)
      y3=a*tanh(b*w2*y2)
      
      % Calculo do gradiente local para a camada de saida
      %delta2 = b/a*(dt(i)-y3).*(a-y3).*(a+y3);
      delta2 = b/a*(1-y3).*(a-y3)'*(a+y3)
      
      % Atualizacao dos pesos da camada de saida
      w2atual=w2+eta2*delta2*y2'
   
      % Calculo do gradiente local para a camada escondida
      w2r = w2(:,2:nEscondida+1)
      
      aux = w2r'*delta2
      delta1=b/a*(a-y1).*(a+y1).*aux
      
      % Atualizacao dos pesos da camada escondida
      w1atual=w1+eta1*delta1*y0'

   % Calculo do erro quadratico medio
   
   yreest = forward([1;1],w1atual,w2atual,a,b)
   erro = 1-forward([1;1],w1atual,w2atual,a,b)



