a = 1.7159;
b = 2.0/3.0;

x=[0;0]
y=forward(x,w1,w2,a,b)
x=[0;1]
y=forward(x,w1,w2,a,b)
x=[1;0]
y=forward(x,w1,w2,a,b)
x=[1;1]
y=forward(x,w1,w2,a,b)
