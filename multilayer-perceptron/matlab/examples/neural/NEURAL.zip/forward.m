function y=forward(x,w1,w2,a,b);
% x : vetor de entrada
% w1: matriz de pesos sinapticos da camada de entrada
% w2: matriz de pesos sinapticos da camada de saida
% y : saida da rede neural
    
y0=[1;x];

% Saida da camada de entrada
y1=a*tanh(b*w1*y0);

% Entrada da camada de saida
y2=[1;y1];

% Saida da camada de saida (saida da rede)
y=a*tanh(b*w2*y2);

